function var2 = mysubfunc(x, var1);
var2 = sum(x) / var1;