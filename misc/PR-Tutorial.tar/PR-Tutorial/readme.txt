Notes:

- mlcv_tutorial.m: basic operations on vectors and matrices

- cv.m: understanding computer vision step-by-step

- RF_SVM: Random Forests and Support Vector Machines. 


To run the files, either launch matlab from the launcher that is included in the tutorial folder, or open a terminal and type 

LD_PRELOAD="/usr/lib/x86_64-linux-gnu/libstdc++.so.6" matlab


